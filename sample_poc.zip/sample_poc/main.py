import dbcredential
import dbconnect

def main():
    uname , pwd = dbcredential.getdbcerdentials()
    print('uname {}',uname)
    print("pwd {}" ,pwd)
    database = dbconnect.db(uname , pwd)
    print(database.create_engine())
    

if __name__ ==  "__main__":
    main()
    
    


from sqlalchemy import create_engine
import pandas as pd
import pymysql

class db():
    db_name = "python"
    tbl_nmae = "emp"
    
    def __init__(self, uname , pwd):
        self.__username = uname
        self.__pwd = pwd
        
    def create_engine(self):
        db_path = "mysql+pymysql://{}:{}@localhost:3306".format(self.__username, self.__pwd)
        sqlengine = create_engine(db_path , pool_recycle = 3600)
        engine = sqlengine.connect()
        return engine